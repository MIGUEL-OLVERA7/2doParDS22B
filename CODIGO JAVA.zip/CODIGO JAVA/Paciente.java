
import java.util.*;

/**
 * 
 */
public class Paciente {

    /**
     * Default constructor
     */
    public Paciente() {
    }

    /**
     * 
     */
    public void Attribute1;

    /**
     * 
     */
    public String nombre;

    /**
     * 
     */
    public String Domicilio;

    /**
     * 
     */
    public Int Edad;

    /**
     * 
     */
    public Double Talla;


    /**
     * 
     */
    public void Operation1() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Nombre() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Domicilio() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Edad() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Talla() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Operation2() {
        // TODO implement here
    }

}