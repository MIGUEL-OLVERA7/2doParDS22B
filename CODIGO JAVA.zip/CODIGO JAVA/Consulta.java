
import java.util.*;

/**
 * 
 */
public class Consulta {

    /**
     * Default constructor
     */
    public Consulta() {
    }

    /**
     * 
     */
    public String Diagnostico;

    /**
     * 
     */
    public String Medico que lo atiende;



    /**
     * 
     */
    public void Diagnostico() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Medico que lo atiende() {
        // TODO implement here
    }

}