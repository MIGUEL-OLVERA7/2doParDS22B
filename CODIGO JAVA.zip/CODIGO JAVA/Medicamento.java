
import java.util.*;

/**
 * 
 */
public class Medicamento {

    /**
     * Default constructor
     */
    public Medicamento() {
    }

    /**
     * 
     */
    public String Nombre Medicamento;

    /**
     * 
     */
    public Int Cantidad;

    /**
     * 
     */
    public Double Precio;

    /**
     * 
     */
    public void Nombre medicamneto() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Cantidad() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Precio() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Operation1() {
        // TODO implement here
    }

}