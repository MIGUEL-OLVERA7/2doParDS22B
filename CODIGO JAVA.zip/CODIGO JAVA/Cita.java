
import java.util.*;

/**
 * 
 */
public class Cita {

    /**
     * Default constructor
     */
    public Cita() {
    }

    /**
     * 
     */
    public Date Fecha;

    /**
     * 
     */
    public String Medico;

    /**
     * 
     */
    public String Nombre Paciente;

    /**
     * 
     */
    public Double Hora;




    /**
     * 
     */
    public void Fecha() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Medico() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Nombre Paciente() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Hora() {
        // TODO implement here
    }

}