
import java.util.*;

/**
 * 
 */
public class Medico {

    /**
     * Default constructor
     */
    public Medico() {
    }

    /**
     * 
     */
    public String Nombre;

    /**
     * 
     */
    public String Domicilio;

    /**
     * 
     */
    public Int Num cedula;

    /**
     * 
     */
    public String Especialidad;


    /**
     * 
     */
    public void Nombre() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Domicilio() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Numero de cedula() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Nombre de quien le dio su titulo() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Especialidad() {
        // TODO implement here
    }

}