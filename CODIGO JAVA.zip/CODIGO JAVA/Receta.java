
import java.util.*;

/**
 * 
 */
public class Receta {

    /**
     * Default constructor
     */
    public Receta() {
    }

    /**
     * 
     */
    public Date Fecha;

    /**
     * 
     */
    public String Firma Medico;

    /**
     * 
     */
    public String Nombre paciente;

    /**
     * 
     */
    public String Medicamentos;



    /**
     * 
     */
    public void Fecha() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Firma medico() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Nombre del paciente() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Denominacion generica() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Dosis() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Medicamentos() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Via de administracion() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Frecuencia() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Duracion del tratamiento() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Cantidad por surtir() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Sello administrativo() {
        // TODO implement here
    }

}